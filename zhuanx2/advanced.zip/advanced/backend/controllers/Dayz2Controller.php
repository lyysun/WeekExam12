<?php
namespace backend\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use common\models\LoginForm;

/**
 * Site controller
 */
class Dayz2Controller extends Controller
{

	 function actionAdd(){
	 	$rand=rand(1111,9999);
	 	// var_dump($rand);die;
	 	$arr=[
              ["username"=>"wang",
              "pwd"=>"12345",
              "rand"=>$rand,
              "time"=>time(),
              ]
	 	  ];
	 	  echo "<pre>";
         // var_dump($arr);die;
	 	  foreach ($arr as $key => $val) {
	 	  	// var_dump($val);
	 	        $str="username=&".$val['username']."pwd=&".$val['pwd']."rand=&".$val['rand']."time=&".$val['time'];

	 	  }
           
	 	   $str=md5($str);
	 	    $str1=$str."secret";
	 	    $sign=md5($str1);
	 	    
	 	   $res=yii::$app->request->get();

	 	   if($res){
	 	     $arr =['status'=>200，'msg'=>'请求成功'],
	 	   	echo json_encode($arr);
	 	   }else{
	 	   	 $arr =['status'=>500，'msg'=>'请求失败'],
	 	   	echo json_encode($arr);
	 	   }

	 }
}