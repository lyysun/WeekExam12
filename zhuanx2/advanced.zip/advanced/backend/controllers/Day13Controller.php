<?php
namespace backend\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use common\models\LoginForm;
use backend\fz\fz;
/**
 * Site controller
 */
class Day13Controller extends Controller
{
  
        function actionAdd(){
        	// echo 22;
        	$data=yii::$app->request->post();
        	// fz::ms(0,$data);
        	var_dump($data);

        	
        }

  }