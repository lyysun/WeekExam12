<?php
namespace backend\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use common\models\LoginForm;

/**
 * Site controller
 */
class LoginController extends Controller
{
	 public $enableCsrfValidation=false;
      function actionLogin(){
      	$data=yii::$app->request->get();
        $data=$data['data'];
        $data=json_decode($data,true);
        
        $name=$data['nickName'];
        $gender=$data['gender'];
        $city=$data['city'];
        $avatarUrl=$data['avatarUrl'];
        $openid="123123";

        yii::$app->db->createCommand("insert into `xiaoshuo-login` (openid,name,gender,city,avatarUrl) values('$openid','$name','$gender','$city','$avatarUrl')")->execute();
            $data=yii::$app->db->createCommand("select * from `xiaoshuo-login` where openid=123123")->queryone();
      	   // var_dump($data);
      	   if($data){
      	   	  echo json_encode($data);
      	   }else{
      	   	echo "0";
      	   }
         
      }

      function actionShowlogin(){
      	   $data=yii::$app->db->createCommand("select * from `xiaoshuo-login` where openid=123123")->queryone();
      	   // var_dump($data);
      	   if($data){
      	   	  echo json_encode($data);
      	   }else{
      	   	echo "0";
      	   }
      }
}