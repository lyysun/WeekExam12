<?php
namespace backend\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use common\models\LoginForm;
use backend\curl\curl;
/**
 * Site controller
 */
class CurlController extends Controller
{
    
     function actionIndex(){
     	  $url="http://47.93.25.138/lyy/x2/advanced/backend/web/index.php?r=day13/add";
     	  
          $data=['a'=>'lyy',"b"=>'eee'];
          $a=curl::curl($url,"GET",$data); 
          var_dump($a);
     }
     


    }