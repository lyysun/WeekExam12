<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<form action="">
		<table>
			<tr>
				<td>选择区域 ：<select name="" id="">
					
					<option value="">西城区</option>
				</select></td>
			</tr>
			<tr>
				<td>录入球队：<input type="text"></td>
			</tr>
			<tr>
				<td><input type="submit" value="提交"></td>
			</tr>
		</table>
	</form>
</body>
</html>