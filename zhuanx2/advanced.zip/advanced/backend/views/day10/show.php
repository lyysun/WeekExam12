<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
耶和华神降下奇迹，使以色列的妻子诞下一子，名为约瑟。约瑟是受神赐福之子，倍受父母的宠爱，招致众异母兄弟的嫉恨。约瑟的兄弟将约瑟卖给以实玛利人，以实玛利人又将约瑟卖至埃及为奴。在埃及，约瑟凭自己的智慧，历经波折后从奴隶成为埃及宰相。
	
	<table>
		<tr>
			<td><input type="radio">1.fffff</td>
		</tr>
		<tr>
			<td><input type="radio">2.eeeeeeeeeee</td>
		</tr>
		<tr>
			<td><input type="radio">3.ttttttttttttt</td>
		</tr>
		<tr>
			<td><input type="submit" value="提交投票"></td>
		</tr>
	</table>
</body>
</html>