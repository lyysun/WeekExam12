<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<h5>创建投票</h5>
	投票标题：<input type="text" name="bt">
	<h5>投票选项</h5>
     <form action="">
     	
     	<table>
     		<tr>
     			<td><input type="text" name="xx"></td>
     		</tr>
     		<tr>
     			<td><input type="submit" value="增加选项"></td>
     		</tr>
     		<tr><td>
     			<input type="submit" value="创建投票">
     		</td></tr>
     	</table>
     </form>
</body>
</html>