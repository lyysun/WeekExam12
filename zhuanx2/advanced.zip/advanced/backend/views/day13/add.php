<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body><form action="">
	
	<table>
		<tr>
			<td>商品名：<input type="text" name="name"></td>
		</tr>
		<tr>
			<td>商品及格：<input type="text" name="name"></td>
		</tr>
		<tr>
			<td>使用的时间<input type="text" name="name"></td>
		</tr>
		<tr>
			<td><input type="submit" value="提交"></td>
		</tr>
	</table>
</form>
	
</body>
</html>