<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<form action="">
		<table>
			<tr>
				<td>用户名：<input type="text"></td>
			</tr>
			<tr>
				<td>昵称<input type="text"></td>
			</tr>
			<tr>
				<td>密码<input type="text"></td>
			</tr>
			<tr>
				<td>角色 <select name="" id="">
					<option value="">董事长</option>
				</select></td>
			</tr>
			<tr>
				<td>备注 <input type="text"></td>
			</tr>
			<tr><td><input type="subumit" value="添加"> <input type="rese" value="重置"></td></tr>
		</table>
	</form>
</body>
</html>