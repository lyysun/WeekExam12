<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
<h3>用户列表</h3>
<button>新增</button> <button>批量删除</button><input type="text"><button>搜索</button>
	<table>
		<tr>
			<td>编号</td>
			<td>用户名</td>
			<td>昵称</td>
			<td>提那家时间</td>
			<td>备注</td>
			<td>角色名称</td>
			<td>操作</td>
		</tr>
		<tr>
			<td>1</td>
			<td>1</td>
			<td>1</td>
			<td>1</td>
			<td>1</td>
			<td>1</td>
			<td>1</td>
		</tr>
	</table>
</body>
</html>