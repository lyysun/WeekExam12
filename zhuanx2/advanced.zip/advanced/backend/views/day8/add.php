<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<form action="">
		<table>
			<tr>
				<td>用户名：<input type="text"　name="name"></td>
			</tr>
			<tr>
				<td>时间：<input type="text" name="sj"></td>
			</tr>
			<tr>
				<td>密码：<input type="text"　name="name"></td>
			</tr>
		</table>
	</form>
</body>
</html>