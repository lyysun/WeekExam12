<?php
return [
    'adminEmail' => 'admin@example.com',
    'api_url'=>'http://47.93.25.138/lyy/x2/advanced/backend/web/index.php?r=',
];
