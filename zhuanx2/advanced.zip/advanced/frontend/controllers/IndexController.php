<?php
namespace frontend\controllers;

use Yii;
use yii\web\Controller;
use frontend\curl\curl;

/**
 * Site controller
 */
class IndexController extends Controller
{     
	  public $enableCsrfValidation=false;
        function actionAdd(){
             // echo 1;die;
         
            return $this->render("add");

            
        	
        }


        function actionShow(){

        	           $url=yii::$app->params['api_url']."index1/show";  
        	
        	           $a=curl::cl($url);
        }

   }